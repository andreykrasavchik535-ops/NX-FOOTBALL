# Blender guide
See ANIMATION_TABLE.md. R15 rig, export FBX, import in Studio Animation Editor, publish, paste id into AnimationIds.