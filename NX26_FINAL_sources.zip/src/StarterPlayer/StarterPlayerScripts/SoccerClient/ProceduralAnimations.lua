--[[ SoccerClient/ProceduralAnimations: generates REAL playable R15 animations at runtime
	 (KeyframeSequence + KeyframeSequenceProvider:RegisterKeyframeSequence). Used by
	 AnimationController ONLY as a fallback when an AnimationIds slot is empty, so your own
	 Blender animations always take priority. Procedural / moderate quality; replace with
	 hand-made Blender animations. UNTESTED in Studio. ]]
local KeyframeSequenceProvider = game:GetService("KeyframeSequenceProvider")
local ProceduralAnimations = {}
local cache = {}
local function pose(name, cf)
	local p = Instance.new("Pose")
	p.Name = name
	p.CFrame = cf or CFrame.new()
	p.Weight = 1
	p.EasingStyle = Enum.PoseEasingStyle.Linear
	p.EasingDirection = Enum.PoseEasingDirection.InOut
	return p
end
local function rig(a)
	a = a or {}
	local root = pose("HumanoidRootPart", a.HumanoidRootPart)
	local rootJ = pose("Root", a.Root); root:AddSubPose(rootJ)
	local waist = pose("Waist", a.Waist); rootJ:AddSubPose(waist)
	waist:AddSubPose(pose("Neck", a.Neck))
	local ls = pose("LeftShoulder", a.LeftShoulder); waist:AddSubPose(ls)
	local le = pose("LeftElbow", a.LeftElbow); ls:AddSubPose(le)
	le:AddSubPose(pose("LeftWrist", a.LeftWrist))
	local rs = pose("RightShoulder", a.RightShoulder); waist:AddSubPose(rs)
	local re = pose("RightElbow", a.RightElbow); rs:AddSubPose(re)
	re:AddSubPose(pose("RightWrist", a.RightWrist))
	local lh = pose("LeftHip", a.LeftHip); rootJ:AddSubPose(lh)
	local lk = pose("LeftKnee", a.LeftKnee); lh:AddSubPose(lk)
	lk:AddSubPose(pose("LeftAnkle", a.LeftAnkle))
	local rh = pose("RightHip", a.RightHip); rootJ:AddSubPose(rh)
	local rk = pose("RightKnee", a.RightKnee); rh:AddSubPose(rk)
	rk:AddSubPose(pose("RightAnkle", a.RightAnkle))
	return root
end
local function makeSeq(name, loop, duration, sampler, steps)
	local seq = Instance.new("KeyframeSequence")
	seq.Name = name
	seq.Loop = loop
	for i = 0, steps do
		local kf = Instance.new("Keyframe")
		kf.Time = (i / steps) * duration
		kf:AddPose(rig(sampler(i / steps)))
		kf.Parent = seq
	end
	return seq
end
local function runSampler(u)
	local ph = u * 2 * math.pi
	local s = math.sin(ph)
	return {
		LeftHip = CFrame.Angles(s * 0.7, 0, 0),
		RightHip = CFrame.Angles(-s * 0.7, 0, 0),
		LeftKnee = CFrame.Angles(math.max(0, -s) * 1.0 + 0.15, 0, 0),
		RightKnee = CFrame.Angles(math.max(0, s) * 1.0 + 0.15, 0, 0),
		LeftAnkle = CFrame.Angles(-s * 0.3, 0, 0),
		RightAnkle = CFrame.Angles(s * 0.3, 0, 0),
		LeftShoulder = CFrame.Angles(-s * 0.6, 0, 0.1),
		RightShoulder = CFrame.Angles(s * 0.6, 0, -0.1),
		LeftElbow = CFrame.Angles(-0.6, 0, 0),
		RightElbow = CFrame.Angles(-0.6, 0, 0),
		Waist = CFrame.Angles(0.12, s * 0.05, 0),
		Root = CFrame.new(0, math.abs(math.cos(ph)) * 0.05, 0),
		Neck = CFrame.Angles(-0.08, 0, 0),
	}
end
local function idleSampler(u)
	local b = math.sin(u * 2 * math.pi)
	return {
		Waist = CFrame.Angles(0.02 + b * 0.02, 0, 0),
		LeftShoulder = CFrame.Angles(0, 0, 0.05 + b * 0.02),
		RightShoulder = CFrame.Angles(0, 0, -0.05 - b * 0.02),
		LeftElbow = CFrame.Angles(-0.15, 0, 0),
		RightElbow = CFrame.Angles(-0.15, 0, 0),
		Root = CFrame.new(0, b * 0.02, 0),
	}
end
local function kickSampler(u)
	local kick
	if u < 0.35 then kick = -(u / 0.35) * 0.9
	elseif u < 0.55 then kick = -0.9 + ((u - 0.35) / 0.2) * 1.8
	else kick = 0.9 * (1 - (u - 0.55) / 0.45) end
	return {
		RightHip = CFrame.Angles(kick, 0, 0),
		RightKnee = CFrame.Angles(math.max(0, -kick) * 0.8 + 0.1, 0, 0),
		LeftHip = CFrame.Angles(-0.15, 0, 0),
		LeftKnee = CFrame.Angles(0.2, 0, 0),
		Waist = CFrame.Angles(0.15, 0, 0),
		LeftShoulder = CFrame.Angles(0.4, 0, 0.3),
		RightShoulder = CFrame.Angles(-0.4, 0, -0.3),
		LeftElbow = CFrame.Angles(-0.7, 0, 0),
		RightElbow = CFrame.Angles(-0.7, 0, 0),
	}
end
local function passSampler(u)
	local k = math.sin(math.min(u / 0.6, 1) * math.pi) * 0.6
	return {
		RightHip = CFrame.Angles(k, 0, 0),
		RightKnee = CFrame.Angles(0.15, 0, 0),
		LeftHip = CFrame.Angles(-0.1, 0, 0),
		Waist = CFrame.Angles(0.1, 0, 0),
		LeftShoulder = CFrame.Angles(0.3, 0, 0.2),
		RightShoulder = CFrame.Angles(-0.3, 0, -0.2),
	}
end
local function tackleSampler(u)
	local lunge = math.sin(math.min(u / 0.7, 1) * math.pi)
	return {
		Root = CFrame.new(0, -lunge * 0.4, 0) * CFrame.Angles(lunge * 0.5, 0, 0),
		Waist = CFrame.Angles(lunge * 0.4, 0, 0),
		LeftHip = CFrame.Angles(-lunge * 0.9, 0, 0),
		RightHip = CFrame.Angles(lunge * 0.5, 0, 0),
		LeftKnee = CFrame.Angles(lunge * 0.9, 0, 0),
		RightKnee = CFrame.Angles(lunge * 0.4, 0, 0),
		LeftShoulder = CFrame.Angles(-lunge * 0.8, 0, 0.3),
		RightShoulder = CFrame.Angles(-lunge * 0.8, 0, -0.3),
	}
end
local GENERATORS = {
	["Locomotion.Idle"] = function() return makeSeq("NX_Idle", true, 2.4, idleSampler, 12) end,
	["Locomotion.RunNoBall"] = function() return makeSeq("NX_Run", true, 0.62, runSampler, 12) end,
	["Locomotion.RunBall"] = function() return makeSeq("NX_RunBall", true, 0.66, runSampler, 12) end,
	["Locomotion.Sprint"] = function() return makeSeq("NX_Sprint", true, 0.5, runSampler, 12) end,
	["Actions.Shoot"] = function() return makeSeq("NX_Shoot", false, 0.55, kickSampler, 14) end,
	["Actions.Pass"] = function() return makeSeq("NX_Pass", false, 0.45, passSampler, 12) end,
	["Actions.Long"] = function() return makeSeq("NX_Long", false, 0.6, kickSampler, 14) end,
	["Actions.TackleFast"] = function() return makeSeq("NX_Tackle", false, 0.6, tackleSampler, 12) end,
	["Actions.TackleSlide"] = function() return makeSeq("NX_Slide", false, 0.8, tackleSampler, 12) end,
}
function ProceduralAnimations.Get(group, key, side)
	local k = group .. "." .. key
	if cache[k] ~= nil then return cache[k] or nil end
	local gen = GENERATORS[k]
	if not gen then cache[k] = false; return nil end
	local ok, id = pcall(function()
		return KeyframeSequenceProvider:RegisterKeyframeSequence(gen())
	end)
	if ok and type(id) == "string" and id ~= "" then
		cache[k] = id
		return id
	end
	cache[k] = false
	return nil
end
return ProceduralAnimations
