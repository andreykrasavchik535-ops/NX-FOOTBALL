--[[ SoccerClient/ProceduralAnimations v2: REAL playable R15 animations generated at runtime
	 (KeyframeSequence + KeyframeSequenceProvider:RegisterKeyframeSequence). Fallback ONLY when an
	 AnimationIds slot is empty; your Blender animations always override. Now covers locomotion,
	 core actions AND all 28 skill moves (side-aware). Procedural / moderate quality; UNTESTED in Studio. ]]
local KeyframeSequenceProvider = game:GetService("KeyframeSequenceProvider")
local ProceduralAnimations = {}
local cache = {}
local function pose(name, cf)
	local p = Instance.new("Pose")
	p.Name = name
	p.CFrame = cf or CFrame.new()
	p.Weight = 1
	p.EasingStyle = Enum.PoseEasingStyle.Linear
	p.EasingDirection = Enum.PoseEasingDirection.InOut
	return p
end
local function rig(a)
	a = a or {}
	local root = pose("HumanoidRootPart", a.HumanoidRootPart)
	local rootJ = pose("Root", a.Root); root:AddSubPose(rootJ)
	local waist = pose("Waist", a.Waist); rootJ:AddSubPose(waist)
	waist:AddSubPose(pose("Neck", a.Neck))
	local ls = pose("LeftShoulder", a.LeftShoulder); waist:AddSubPose(ls)
	local le = pose("LeftElbow", a.LeftElbow); ls:AddSubPose(le)
	le:AddSubPose(pose("LeftWrist", a.LeftWrist))
	local rs = pose("RightShoulder", a.RightShoulder); waist:AddSubPose(rs)
	local re = pose("RightElbow", a.RightElbow); rs:AddSubPose(re)
	re:AddSubPose(pose("RightWrist", a.RightWrist))
	local lh = pose("LeftHip", a.LeftHip); rootJ:AddSubPose(lh)
	local lk = pose("LeftKnee", a.LeftKnee); lh:AddSubPose(lk)
	lk:AddSubPose(pose("LeftAnkle", a.LeftAnkle))
	local rh = pose("RightHip", a.RightHip); rootJ:AddSubPose(rh)
	local rk = pose("RightKnee", a.RightKnee); rh:AddSubPose(rk)
	rk:AddSubPose(pose("RightAnkle", a.RightAnkle))
	return root
end
local function makeSeq(name, loop, duration, sampler, steps)
	local seq = Instance.new("KeyframeSequence")
	seq.Name = name
	seq.Loop = loop
	for i = 0, steps do
		local kf = Instance.new("Keyframe")
		kf.Time = (i / steps) * duration
		kf:AddPose(rig(sampler(i / steps)))
		kf.Parent = seq
	end
	return seq
end
-- locomotion / actions (improved amplitudes)
local function runSampler(u)
	local ph = u * 2 * math.pi
	local s = math.sin(ph)
	local c = math.cos(ph)
	return {
		LeftHip = CFrame.Angles(s * 0.85, 0, 0.03),
		RightHip = CFrame.Angles(-s * 0.85, 0, -0.03),
		LeftKnee = CFrame.Angles(math.max(0, -s) * 1.3 + 0.2, 0, 0),
		RightKnee = CFrame.Angles(math.max(0, s) * 1.3 + 0.2, 0, 0),
		LeftAnkle = CFrame.Angles(-s * 0.4 + 0.1, 0, 0),
		RightAnkle = CFrame.Angles(s * 0.4 + 0.1, 0, 0),
		LeftShoulder = CFrame.Angles(-s * 0.7, 0, 0.12),
		RightShoulder = CFrame.Angles(s * 0.7, 0, -0.12),
		LeftElbow = CFrame.Angles(-0.9, 0, 0),
		RightElbow = CFrame.Angles(-0.9, 0, 0),
		Waist = CFrame.Angles(0.18, s * 0.06, 0),
		Root = CFrame.new(0, math.abs(c) * 0.06, 0),
		Neck = CFrame.Angles(-0.1, 0, 0),
	}
end
local function sprintSampler(u)
	local ph = u * 2 * math.pi
	local s = math.sin(ph)
	local c = math.cos(ph)
	return {
		LeftHip = CFrame.Angles(s * 1.05, 0, 0.04),
		RightHip = CFrame.Angles(-s * 1.05, 0, -0.04),
		LeftKnee = CFrame.Angles(math.max(0, -s) * 1.6 + 0.25, 0, 0),
		RightKnee = CFrame.Angles(math.max(0, s) * 1.6 + 0.25, 0, 0),
		LeftAnkle = CFrame.Angles(-s * 0.5 + 0.15, 0, 0),
		RightAnkle = CFrame.Angles(s * 0.5 + 0.15, 0, 0),
		LeftShoulder = CFrame.Angles(-s * 0.9, 0, 0.15),
		RightShoulder = CFrame.Angles(s * 0.9, 0, -0.15),
		LeftElbow = CFrame.Angles(-1.1, 0, 0),
		RightElbow = CFrame.Angles(-1.1, 0, 0),
		Waist = CFrame.Angles(0.28, s * 0.08, 0),
		Root = CFrame.new(0, math.abs(c) * 0.08, 0),
		Neck = CFrame.Angles(-0.15, 0, 0),
	}
end
local function idleSampler(u)
	local b = math.sin(u * 2 * math.pi)
	return {
		Waist = CFrame.Angles(0.02 + b * 0.02, 0, 0),
		LeftShoulder = CFrame.Angles(0, 0, 0.05 + b * 0.02),
		RightShoulder = CFrame.Angles(0, 0, -0.05 - b * 0.02),
		LeftElbow = CFrame.Angles(-0.15, 0, 0),
		RightElbow = CFrame.Angles(-0.15, 0, 0),
		Root = CFrame.new(0, b * 0.02, 0),
	}
end
local function kickSampler(u)
	local kick
	if u < 0.3 then kick = -(u / 0.3) * 1.1
	elseif u < 0.5 then kick = -1.1 + ((u - 0.3) / 0.2) * 2.2
	else kick = 1.1 * (1 - (u - 0.5) / 0.5) end
	return {
		RightHip = CFrame.Angles(kick, 0, 0),
		RightKnee = CFrame.Angles(math.max(0, -kick) * 1.0 + 0.15, 0, 0),
		RightAnkle = CFrame.Angles(math.max(0, kick) * 0.3, 0, 0),
		LeftHip = CFrame.Angles(-0.2, 0, 0),
		LeftKnee = CFrame.Angles(0.35, 0, 0),
		Waist = CFrame.Angles(0.2, -kick * 0.1, 0),
		LeftShoulder = CFrame.Angles(0.5, 0, 0.4),
		RightShoulder = CFrame.Angles(-0.5, 0, -0.4),
		LeftElbow = CFrame.Angles(-0.8, 0, 0),
		RightElbow = CFrame.Angles(-0.8, 0, 0),
	}
end
local function passSampler(u)
	local k = math.sin(math.min(u / 0.6, 1) * math.pi) * 0.7
	return {
		RightHip = CFrame.Angles(k, 0, 0),
		RightKnee = CFrame.Angles(0.2, 0, 0),
		LeftHip = CFrame.Angles(-0.12, 0, 0),
		Waist = CFrame.Angles(0.12, 0, 0),
		LeftShoulder = CFrame.Angles(0.3, 0, 0.2),
		RightShoulder = CFrame.Angles(-0.3, 0, -0.2),
	}
end
local function tackleSampler(u)
	local lunge = math.sin(math.min(u / 0.7, 1) * math.pi)
	return {
		Root = CFrame.new(0, -lunge * 0.4, 0) * CFrame.Angles(lunge * 0.5, 0, 0),
		Waist = CFrame.Angles(lunge * 0.4, 0, 0),
		LeftHip = CFrame.Angles(-lunge * 0.9, 0, 0),
		RightHip = CFrame.Angles(lunge * 0.5, 0, 0),
		LeftKnee = CFrame.Angles(lunge * 0.9, 0, 0),
		RightKnee = CFrame.Angles(lunge * 0.4, 0, 0),
		LeftShoulder = CFrame.Angles(-lunge * 0.8, 0, 0.3),
		RightShoulder = CFrame.Angles(-lunge * 0.8, 0, -0.3),
	}
end
-- feint archetypes (u, side, params). Gross body spin/burst is applied by FeintAnimator;
-- these animate the footwork / torso. Lateral components mirror with side.
local function stepover(u, side, p)
	local reps = (p and p.reps) or 1
	local ph = u * reps * 2 * math.pi
	local swing = math.sin(ph)
	local lift = math.max(0, math.sin(ph))
	return {
		RightHip = CFrame.Angles(-0.3 * lift, 0, side * (0.5 * swing + 0.3)),
		RightKnee = CFrame.Angles(0.6 * lift + 0.2, 0, 0),
		LeftHip = CFrame.Angles(-0.1, 0, 0),
		LeftKnee = CFrame.Angles(0.2, 0, 0),
		Waist = CFrame.Angles(0.1, side * 0.15 * swing, side * 0.08),
		LeftShoulder = CFrame.Angles(0, 0, side * 0.2),
		RightShoulder = CFrame.Angles(0, 0, -side * 0.2),
	}
end
local function spinfeint(u, side, p)
	local deg = (p and p.deg) or 360
	local tw = math.sin(u * math.pi)
	local sweep = math.sin(u * 2 * math.pi)
	return {
		Waist = CFrame.Angles(0.1, side * tw * math.rad(deg) * 0.3, 0),
		RightHip = CFrame.Angles(-0.4 * tw, 0, side * 0.4 * sweep),
		RightKnee = CFrame.Angles(0.5 * tw + 0.2, 0, 0),
		LeftHip = CFrame.Angles(0.2 * tw, 0, 0),
		LeftShoulder = CFrame.Angles(0, 0, side * 0.3 * tw),
		RightShoulder = CFrame.Angles(0, 0, -side * 0.3 * tw),
		Root = CFrame.new(0, -0.1 * tw, 0),
	}
end
local function flick(u, side, p)
	local high = p and p.high
	local k
	if u < 0.4 then k = -(u / 0.4) * 0.5
	elseif u < 0.6 then k = -0.5 + ((u - 0.4) / 0.2) * (high and 2.0 or 1.4)
	else k = (high and 1.5 or 0.9) * (1 - (u - 0.6) / 0.4) end
	return {
		RightHip = CFrame.Angles(k, 0, 0),
		RightKnee = CFrame.Angles(math.max(0, -k) * 0.8 + 0.2, 0, 0),
		LeftHip = CFrame.Angles(-0.15, 0, 0),
		Waist = CFrame.Angles(high and -0.15 or 0.1, 0, 0),
		LeftShoulder = CFrame.Angles(0.3, 0, 0.2),
		RightShoulder = CFrame.Angles(-0.3, 0, -0.2),
	}
end
local function elastico(u, side, p)
	local dir = (p and p.reverse) and -1 or 1
	local out = math.sin(u * 2 * math.pi) * dir
	return {
		RightHip = CFrame.Angles(-0.2, 0, side * out * 0.5),
		RightKnee = CFrame.Angles(0.3, 0, 0),
		LeftHip = CFrame.Angles(-0.1, 0, 0),
		Waist = CFrame.Angles(0.1, side * out * 0.15, side * out * 0.08),
		LeftShoulder = CFrame.Angles(0, 0, side * 0.15),
		RightShoulder = CFrame.Angles(0, 0, -side * 0.15),
	}
end
local function bodyfeint(u, side, p)
	local amp = (p and p.advanced) and 0.25 or 0.15
	local drop = math.sin(u * 2 * math.pi)
	return {
		Waist = CFrame.Angles(0.08, 0, side * drop * amp),
		Root = CFrame.new(0, -math.abs(drop) * 0.1, 0),
		LeftShoulder = CFrame.Angles(0, 0, side * (0.2 + drop * 0.15)),
		RightShoulder = CFrame.Angles(0, 0, -side * (0.2 - drop * 0.15)),
		LeftHip = CFrame.Angles(-0.1, 0, side * drop * 0.1),
		RightHip = CFrame.Angles(-0.1, 0, -side * drop * 0.1),
		LeftKnee = CFrame.Angles(0.25, 0, 0),
		RightKnee = CFrame.Angles(0.25, 0, 0),
	}
end
local function cut(u, side, p)
	local shift = math.sin(u * math.pi)
	return {
		RightHip = CFrame.Angles(-0.3 * shift, 0, side * 0.5 * shift),
		RightKnee = CFrame.Angles(0.5 * shift + 0.2, 0, 0),
		LeftHip = CFrame.Angles(-0.1, 0, 0),
		Waist = CFrame.Angles(0.12, side * 0.2 * shift, side * 0.1 * shift),
		LeftShoulder = CFrame.Angles(0, 0, side * 0.2),
		RightShoulder = CFrame.Angles(0, 0, -side * 0.2),
	}
end
local function dragback(u, side, p)
	local pull = math.sin(u * math.pi)
	return {
		RightHip = CFrame.Angles(pull * 0.6, 0, 0),
		RightKnee = CFrame.Angles(0.3, 0, 0),
		LeftHip = CFrame.Angles(-0.15, 0, 0),
		Waist = CFrame.Angles(0.15, 0, 0),
		Root = CFrame.new(0, -0.08 * pull, 0),
		LeftShoulder = CFrame.Angles(0.3, 0, 0.2),
		RightShoulder = CFrame.Angles(-0.3, 0, -0.2),
	}
end
local function roll(u, side, p)
	local across = math.sin(u * 2 * math.pi)
	return {
		RightHip = CFrame.Angles(-0.25, 0, side * across * 0.4),
		RightKnee = CFrame.Angles(0.35, 0, 0),
		LeftHip = CFrame.Angles(-0.1, 0, 0),
		Waist = CFrame.Angles(0.1, side * across * 0.1, side * across * 0.06),
		LeftShoulder = CFrame.Angles(0, 0, side * 0.15),
		RightShoulder = CFrame.Angles(0, 0, -side * 0.15),
	}
end
local function stopgo(u, side, p)
	local stop = u < 0.4 and math.sin((u / 0.4) * math.pi) or 0
	local go = u >= 0.4 and math.sin(((u - 0.4) / 0.6) * math.pi) or 0
	return {
		RightHip = CFrame.Angles(-stop * 0.3 + go * 0.7, 0, 0),
		RightKnee = CFrame.Angles(stop * 0.4 + 0.2, 0, 0),
		LeftHip = CFrame.Angles(-stop * 0.2 - go * 0.4, 0, 0),
		LeftKnee = CFrame.Angles(stop * 0.3 + go * 0.5 + 0.2, 0, 0),
		Waist = CFrame.Angles(stop * 0.1 + go * 0.2, 0, 0),
		Root = CFrame.new(0, -stop * 0.1, 0),
		LeftShoulder = CFrame.Angles(-go * 0.5, 0, 0.2),
		RightShoulder = CFrame.Angles(go * 0.5, 0, -0.2),
	}
end
local function nutmeg(u, side, p)
	local push = math.sin(u * math.pi)
	return {
		RightHip = CFrame.Angles(-push * 0.5, 0, 0),
		RightKnee = CFrame.Angles(0.3, 0, 0),
		LeftHip = CFrame.Angles(-0.1, 0, 0),
		Waist = CFrame.Angles(0.15, 0, 0),
		LeftShoulder = CFrame.Angles(0.3, 0, 0.2),
		RightShoulder = CFrame.Angles(-0.3, 0, -0.2),
	}
end
local function fakeshot(u, side, p)
	local wind = u < 0.4 and (u / 0.4) or 1
	local pull = u >= 0.4 and math.sin(((u - 0.4) / 0.6) * math.pi) or 0
	return {
		RightHip = CFrame.Angles(-wind * 0.9 + pull * 0.6, 0, 0),
		RightKnee = CFrame.Angles(wind * 0.8 + 0.2, 0, 0),
		LeftHip = CFrame.Angles(-0.15, 0, 0),
		Waist = CFrame.Angles(0.15, 0, 0),
		LeftShoulder = CFrame.Angles(0.4, 0, 0.3),
		RightShoulder = CFrame.Angles(-0.4, 0, -0.3),
	}
end
local FEINTS = {
	StepOver = { stepover, { reps = 1 }, 0.55 },
	DoubleStepOver = { stepover, { reps = 2 }, 0.85 },
	Roulette = { spinfeint, { deg = 360 }, 0.7 },
	RainbowFlick = { flick, { high = true }, 0.9 },
	HeelFlick = { flick, { high = false }, 0.55 },
	Elastico = { elastico, { reverse = false }, 0.6 },
	ReverseElastico = { elastico, { reverse = true }, 0.7 },
	BodyFeint = { bodyfeint, { advanced = false }, 0.35 },
	BallRoll = { roll, {}, 0.5 },
	FakeShot = { fakeshot, {}, 0.55 },
	Nutmeg = { nutmeg, {}, 0.6 },
	DragBack = { dragback, {}, 0.65 },
	LaCroqueta = { cut, {}, 0.4 },
	McGeadySpin = { spinfeint, { deg = 360 }, 0.75 },
	HeelToHeel = { roll, {}, 0.65 },
	BodyFeintCut = { bodyfeint, { advanced = true }, 0.5 },
	TwoTouchQuick = { roll, {}, 0.38 },
	Chop = { cut, {}, 0.5 },
	RouletteBurst = { spinfeint, { deg = 360 }, 0.5 },
	DoubleTouch = { roll, {}, 0.4 },
	StepoverExit = { stepover, { reps = 1 }, 0.45 },
	LateralHeelToHeel = { roll, {}, 0.5 },
	SombreroFlick = { flick, { high = true }, 0.8 },
	StopAndGo = { stopgo, {}, 0.65 },
	ScoopTurn = { spinfeint, { deg = 180 }, 0.6 },
	VCut = { cut, {}, 0.5 },
	BerbaSpin = { spinfeint, { deg = 90 }, 0.55 },
	AdvancedBodyFeint = { bodyfeint, { advanced = true }, 0.5 },
}
local GENERATORS = {
	["Locomotion.Idle"] = function() return makeSeq("NX_Idle", true, 2.4, idleSampler, 12) end,
	["Locomotion.RunNoBall"] = function() return makeSeq("NX_Run", true, 0.62, runSampler, 12) end,
	["Locomotion.RunBall"] = function() return makeSeq("NX_RunBall", true, 0.66, runSampler, 12) end,
	["Locomotion.Sprint"] = function() return makeSeq("NX_Sprint", true, 0.5, sprintSampler, 12) end,
	["Actions.Shoot"] = function() return makeSeq("NX_Shoot", false, 0.55, kickSampler, 14) end,
	["Actions.Pass"] = function() return makeSeq("NX_Pass", false, 0.45, passSampler, 12) end,
	["Actions.Long"] = function() return makeSeq("NX_Long", false, 0.6, kickSampler, 14) end,
	["Actions.TackleFast"] = function() return makeSeq("NX_Tackle", false, 0.6, tackleSampler, 12) end,
	["Actions.TackleSlide"] = function() return makeSeq("NX_Slide", false, 0.8, tackleSampler, 12) end,
}
for id, cfg in pairs(FEINTS) do
	local fn, params, dur = cfg[1], cfg[2], cfg[3]
	GENERATORS["Feints." .. id] = function(side)
		return makeSeq("NX_" .. id, false, dur, function(u) return fn(u, side, params) end, 12)
	end
end
function ProceduralAnimations.Get(group, key, side)
	side = (side == -1) and -1 or 1
	local gk = group .. "." .. key
	local ck = gk .. ":" .. side
	if cache[ck] ~= nil then return cache[ck] or nil end
	local gen = GENERATORS[gk]
	if not gen then cache[ck] = false; return nil end
	local ok, id = pcall(function()
		return KeyframeSequenceProvider:RegisterKeyframeSequence(gen(side))
	end)
	if ok and type(id) == "string" and id ~= "" then
		cache[ck] = id
		return id
	end
	cache[ck] = false
	return nil
end
return ProceduralAnimations
