--[[
	StarterPlayerScripts/SoccerClient/SetPieceUI (ModuleScript)
	Free kick / penalty screen, like a console pad drawn on the screen:
	  * left: a JOYSTICK ring - drag it (or WASD / arrows / gamepad stick) to move the aim reticle over the goal
	  * centre: the goal frame with the aim reticle (left..right post, ground..crossbar; a bit outside = a miss)
	  * right: SHOOT button (hold = power bar fills, release to strike), shot style pills, curve side
	Shown only for the player who takes the kick (SoccerState attribute SetPieceTaker == his UserId).
	Sends  SetPieceKick(aimX, aimY, power, style, side)  - the server turns that into a real kick.
]]
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local UserInputService = game:GetService("UserInputService")
local Workspace = game:GetService("Workspace")

local Shared = ReplicatedStorage:WaitForChild("SoccerShared")
local Config = require(Shared:WaitForChild("Config"))
local Remotes = require(Shared:WaitForChild("Remotes"))
local UIKit = require(script.Parent:WaitForChild("UIKit"))

local T = UIKit.Theme
local player = Players.LocalPlayer

local UI = {}
local gui, root, stateFolder
local ui = {}
local active = false
local aim = { x = 0, y = 0.35 }
local stickX, stickY = 0, 0      -- from the on-screen ring (-1..1, y up)
local padX, padY = 0, 0          -- from a gamepad
local ringTouch = nil
local charging, chargeT0, power = false, 0, 0
local style, side = "Normal", 1
local sentAt = nil
local STYLES = { "Normal", "Finesse", "Trivela", "Knuckle" }
local STYLE_TEXT = { Normal = "NORMAL", Finesse = "FINESSE", Trivela = "TRIVELA", Knuckle = "KNUCKLE" }
local AIM_SPEED_X, AIM_SPEED_Y = 1.15, 0.8
local CHARGE_SECONDS = 1.1

local function serverNow()
	local ok, t = pcall(function() return Workspace:GetServerTimeNow() end)
	return ok and t or os.clock()
end

-- keyboard stick (WASD / arrows)
local function keyStick() -- returns x, y (not normalised)
	local x, y = 0, 0
	local function down(k)
		local ok, r = pcall(function() return UserInputService:IsKeyDown(k) end)
		return ok and r
	end
	if down(Enum.KeyCode.A) or down(Enum.KeyCode.Left) then x = x - 1 end
	if down(Enum.KeyCode.D) or down(Enum.KeyCode.Right) then x = x + 1 end
	if down(Enum.KeyCode.W) or down(Enum.KeyCode.Up) then y = y + 1 end
	if down(Enum.KeyCode.S) or down(Enum.KeyCode.Down) then y = y - 1 end
	return x, y
end

-- UI helpers ------------------------------------------------------------------------------------------------------

local function round(parent, props, strokeAlpha)
	local f = UIKit.frame(parent, props)
	UIKit.corner(f, UDim.new(1, 0))
	if strokeAlpha then
		UIKit.stroke(f, T.line, 1.4, strokeAlpha)
	end
	return f
end

local function setStyle(name)
	style = name
	for _, n in ipairs(STYLES) do
		local b = ui.styleBtn[n]
		local on = n == name
		b.BackgroundTransparency = on and 0.05 or T.btnAlpha
		b.BackgroundColor3 = on and T.btnDown or T.btn
		b.TextTransparency = on and 0 or 0.25
	end
	local curved = (name == "Finesse" or name == "Trivela")
	ui.sideBtn.Visible = curved
end

local function setSide(v)
	side = v
	ui.sideBtn.Text = "CURVE  " .. (side == 1 and "RIGHT >" or "< LEFT")
end

local function updateReticle()
	-- goal frame: x -1..1 left..right, y 0..1 bottom..top
	ui.reticle.Position = UDim2.fromScale(0.5 + aim.x * 0.5, 1 - aim.y)
	local out = math.abs(aim.x) > 1 or aim.y > 1
	ui.reticle.BackgroundTransparency = out and 0.55 or 0.85
	ui.reticleStroke.Color = out and T.bad or T.line
end

local function updatePower()
	local p = power
	ui.barFill.Size = UDim2.fromScale(p, 1)
	local sweetMin, sweetMax = Config.SETPIECE_SWEET_MIN or 0.55, Config.SETPIECE_SWEET_MAX or 0.9
	local inSweet = p >= sweetMin and p <= sweetMax
	ui.barFill.BackgroundColor3 = (p > sweetMax) and T.bad or (inSweet and T.good or T.accent)
	ui.barText.Text = charging and string.format("%d%%", math.floor(p * 100 + 0.5)) or "POWER"
end

local function setBarVisible(v)
	local pg = player:FindFirstChild("PlayerGui")
	if not pg then return end
	for _, d in ipairs(pg:GetDescendants()) do
		if d.Name == "ActionBar" and d.Visible ~= nil then
			if not v then
				ui._barWas = ui._barWas or {}
				ui._barWas[d] = d.Visible
				d.Visible = false
			else
				if ui._barWas and ui._barWas[d] ~= nil then d.Visible = ui._barWas[d] end
			end
		end
	end
	if v then ui._barWas = nil end
end

-- Build -------------------------------------------------------------------------------------------------------------

function UI.Build()
	if gui then return gui end
	local u = UIKit.unit()
	ui.u = u
	gui = Instance.new("ScreenGui")
	gui.Name = "NXSetPiece"
	gui.ResetOnSpawn = false
	gui.IgnoreGuiInset = true
	gui.DisplayOrder = 20
	gui.Enabled = false
	gui.Parent = player:WaitForChild("PlayerGui")

	root = UIKit.frame(gui, { Name = "Root", Size = UDim2.fromScale(1, 1), BackgroundTransparency = 1 })

	-- title + timer
	ui.title = UIKit.label(root, { Name = "Title", AnchorPoint = Vector2.new(0.5, 0), Position = UDim2.new(0.5, 0, 0, u * 0.3), Size = UDim2.fromOffset(u * 8, u * 0.7), Text = "FREE KICK", Font = UIKit.FONT_TITLE, TextSize = math.floor(u * 0.5), TextColor3 = T.text })
	ui.sub = UIKit.label(root, { Name = "Sub", AnchorPoint = Vector2.new(0.5, 0), Position = UDim2.new(0.5, 0, 0, u * 0.95), Size = UDim2.fromOffset(u * 8, u * 0.4), Text = "", TextSize = math.floor(u * 0.26), TextColor3 = T.dim })

	-- the goal
	local gw, gh = u * 8.4, u * 2.9
	ui.goal = UIKit.frame(root, { Name = "Goal", AnchorPoint = Vector2.new(0.5, 0), Position = UDim2.new(0.5, 0, 0, u * 1.55), Size = UDim2.fromOffset(gw, gh), BackgroundColor3 = T.btn, BackgroundTransparency = 0.7 })
	UIKit.stroke(ui.goal, T.line, 3, 0.15) -- posts + crossbar
	for i = 1, 11 do -- net
		UIKit.frame(ui.goal, { Name = "NetV" .. i, Position = UDim2.fromScale(i / 12, 0), Size = UDim2.new(0, 1, 1, 0), BackgroundColor3 = T.line, BackgroundTransparency = 0.9 })
	end
	for i = 1, 4 do
		UIKit.frame(ui.goal, { Name = "NetH" .. i, Position = UDim2.fromScale(0, i / 5), Size = UDim2.new(1, 0, 0, 1), BackgroundColor3 = T.line, BackgroundTransparency = 0.9 })
	end
	ui.reticle = round(ui.goal, { Name = "Reticle", AnchorPoint = Vector2.new(0.5, 0.5), Size = UDim2.fromOffset(u * 0.62, u * 0.62), BackgroundColor3 = T.text, BackgroundTransparency = 0.85, ZIndex = 3 })
	ui.reticleStroke = UIKit.stroke(ui.reticle, T.line, 2, 0.05)
	local dot = round(ui.reticle, { Name = "Dot", AnchorPoint = Vector2.new(0.5, 0.5), Position = UDim2.fromScale(0.5, 0.5), Size = UDim2.fromOffset(5, 5), BackgroundColor3 = T.text, ZIndex = 4 })
	ui.dist = UIKit.label(root, { Name = "Dist", AnchorPoint = Vector2.new(0.5, 0), Position = UDim2.new(0.5, 0, 0, u * 1.6 + gh + 6), Size = UDim2.fromOffset(u * 6, u * 0.35), Text = "", TextSize = math.floor(u * 0.24), TextColor3 = T.dim })

	-- joystick ring (bottom left)
	local rs = u * 2.7
	ui.ring = round(root, { Name = "StickRing", AnchorPoint = Vector2.new(0, 1), Position = UDim2.new(0, u * 0.7, 1, -u * 0.5), Size = UDim2.fromOffset(rs, rs), BackgroundColor3 = T.btn, BackgroundTransparency = T.btnAlpha, Active = true }, T.lineAlpha)
	ui.ringSize = rs
	ui.knob = round(ui.ring, { Name = "StickKnob", AnchorPoint = Vector2.new(0.5, 0.5), Position = UDim2.fromScale(0.5, 0.5), Size = UDim2.fromOffset(rs * 0.42, rs * 0.42), BackgroundColor3 = T.btnDown, BackgroundTransparency = 0.15 }, 0.4)
	UIKit.label(ui.ring, { Name = "ArrowU", AnchorPoint = Vector2.new(0.5, 0), Position = UDim2.fromScale(0.5, 0.02), Size = UDim2.fromOffset(rs * 0.3, rs * 0.2), Text = "^", TextSize = math.floor(u * 0.3), TextTransparency = 0.5 })
	UIKit.label(ui.ring, { Name = "ArrowD", AnchorPoint = Vector2.new(0.5, 1), Position = UDim2.fromScale(0.5, 0.98), Size = UDim2.fromOffset(rs * 0.3, rs * 0.2), Text = "v", TextSize = math.floor(u * 0.26), TextTransparency = 0.5 })
	UIKit.label(ui.ring, { Name = "ArrowL", AnchorPoint = Vector2.new(0, 0.5), Position = UDim2.fromScale(0.03, 0.5), Size = UDim2.fromOffset(rs * 0.2, rs * 0.3), Text = "<", TextSize = math.floor(u * 0.3), TextTransparency = 0.5 })
	UIKit.label(ui.ring, { Name = "ArrowR", AnchorPoint = Vector2.new(1, 0.5), Position = UDim2.fromScale(0.97, 0.5), Size = UDim2.fromOffset(rs * 0.2, rs * 0.3), Text = ">", TextSize = math.floor(u * 0.3), TextTransparency = 0.5 })

	-- shoot button (bottom right) + power bar
	local ss = u * 1.95
	ui.shoot = UIKit.button(root, { Name = "ShootButton", AnchorPoint = Vector2.new(1, 1), Position = UDim2.new(1, -u * 0.6, 1, -u * 0.5), Size = UDim2.fromOffset(ss, ss), Text = "SHOOT", TextSize = math.floor(u * 0.3), BackgroundColor3 = T.btn, BackgroundTransparency = T.btnAlpha })
	UIKit.corner(ui.shoot, UDim.new(1, 0))
	UIKit.stroke(ui.shoot, T.line, 1.6, T.lineAlpha)

	local bw = u * 3.6
	ui.bar = UIKit.frame(root, { Name = "PowerBar", AnchorPoint = Vector2.new(1, 1), Position = UDim2.new(1, -(u * 0.6 + ss + u * 0.25), 1, -(u * 0.5 + ss * 0.5 - u * 0.16)), Size = UDim2.fromOffset(bw, u * 0.32), BackgroundColor3 = T.btn, BackgroundTransparency = 0.4 })
	UIKit.corner(ui.bar, UDim.new(0, 6))
	UIKit.stroke(ui.bar, T.line, 1.2, T.lineAlpha)
	local sMin, sMax = Config.SETPIECE_SWEET_MIN or 0.55, Config.SETPIECE_SWEET_MAX or 0.9
	ui.sweet = UIKit.frame(ui.bar, { Name = "Sweet", Position = UDim2.fromScale(sMin, 0), Size = UDim2.fromScale(sMax - sMin, 1), BackgroundColor3 = T.good, BackgroundTransparency = 0.72 })
	ui.barFill = UIKit.frame(ui.bar, { Name = "Fill", Size = UDim2.fromScale(0, 1), BackgroundColor3 = T.accent, BackgroundTransparency = 0.1, ZIndex = 2 })
	UIKit.corner(ui.barFill, UDim.new(0, 6))
	ui.barText = UIKit.label(ui.bar, { Name = "BarText", AnchorPoint = Vector2.new(1, 1), Position = UDim2.new(1, 0, 0, -3), Size = UDim2.fromOffset(bw, u * 0.3), Text = "POWER", TextSize = math.floor(u * 0.22), TextXAlignment = Enum.TextXAlignment.Right, TextColor3 = T.dim, ZIndex = 3 })

	-- style pills (above the shoot button)
	ui.styleBtn = {}
	local pw, ph, gap = u * 1.4, u * 0.5, u * 0.1
	for i, n in ipairs(STYLES) do
		local b = UIKit.button(root, { Name = "Style_" .. n, AnchorPoint = Vector2.new(1, 1), Position = UDim2.new(1, -(u * 0.6 + (#STYLES - i) * (pw + gap)), 1, -(u * 0.5 + ss + u * 0.2)), Size = UDim2.fromOffset(pw, ph), Text = STYLE_TEXT[n], TextSize = math.floor(u * 0.2), BackgroundColor3 = T.btn, BackgroundTransparency = T.btnAlpha })
		UIKit.corner(b, UDim.new(0, math.floor(ph / 2)))
		UIKit.stroke(b, T.line, 1.2, T.lineAlpha)
		b.Activated:Connect(function() setStyle(n) end)
		ui.styleBtn[n] = b
	end
	ui.sideBtn = UIKit.button(root, { Name = "SideButton", AnchorPoint = Vector2.new(1, 1), Position = UDim2.new(1, -u * 0.6, 1, -(u * 0.5 + ss + u * 0.2 + ph + u * 0.12)), Size = UDim2.fromOffset(u * 2.2, ph), Text = "", TextSize = math.floor(u * 0.2), BackgroundColor3 = T.btn, BackgroundTransparency = T.btnAlpha, Visible = false })
	UIKit.corner(ui.sideBtn, UDim.new(0, math.floor(ph / 2)))
	UIKit.stroke(ui.sideBtn, T.line, 1.2, T.lineAlpha)
	ui.sideBtn.Activated:Connect(function() setSide(-side) end)

	ui.hint = UIKit.label(root, { Name = "Hint", AnchorPoint = Vector2.new(0.5, 1), Position = UDim2.new(0.5, 0, 1, -u * 0.12), Size = UDim2.fromOffset(u * 9, u * 0.3), Text = "Stick - aim   |   hold SHOOT, release in the green zone", TextSize = math.floor(u * 0.19), TextColor3 = T.dim })

	-- input: joystick ring
	ui.ring.InputBegan:Connect(function(input)
		local t = input.UserInputType
		if t == Enum.UserInputType.MouseButton1 or t == Enum.UserInputType.Touch then
			ringTouch = input
			UI._moveRing(input.Position)
		end
	end)
	UserInputService.InputChanged:Connect(function(input)
		if input.UserInputType == Enum.UserInputType.Gamepad1 and input.KeyCode == Enum.KeyCode.Thumbstick1 then
			padX, padY = input.Position.X, input.Position.Y
		elseif ringTouch and (input == ringTouch or input.UserInputType == Enum.UserInputType.MouseMovement) then
			UI._moveRing(input.Position)
		end
	end)
	UserInputService.InputEnded:Connect(function(input)
		if ringTouch and (input == ringTouch or input.UserInputType == Enum.UserInputType.MouseButton1 or input.UserInputType == Enum.UserInputType.Touch) then
			ringTouch = nil
			stickX, stickY = 0, 0
			ui.knob.Position = UDim2.fromScale(0.5, 0.5)
		end
		if input.KeyCode == Enum.KeyCode.E or input.KeyCode == Enum.KeyCode.ButtonA then
			UI._release()
		end
	end)
	UserInputService.InputBegan:Connect(function(input, processed)
		if active and (input.KeyCode == Enum.KeyCode.E or input.KeyCode == Enum.KeyCode.ButtonA) then
			UI._press()
		end
	end)

	UIKit.hold(ui.shoot, function() UI._press() end, function() UI._release() end)

	setStyle("Normal")
	setSide(1)
	updateReticle()
	updatePower()
	return gui
end

-- stick / shoot logic ------------------------------------------------------------------------------------------------

function UI._moveRing(pos)
	local ap, as = ui.ring.AbsolutePosition, ui.ring.AbsoluteSize
	local r = math.max(as.X / 2, 1)
	local vx, vy = (pos.X - (ap.X + as.X / 2)) / r, (pos.Y - (ap.Y + as.Y / 2)) / r
	local len = math.sqrt(vx * vx + vy * vy)
	if len > 1 then vx, vy = vx / len, vy / len end
	stickX, stickY = vx, -vy -- screen y goes down, the aim goes up
	local k = ui.ringSize * 0.29
	ui.knob.Position = UDim2.new(0.5, vx * k, 0.5, vy * k)
end

function UI._press()
	if not active or charging or sentAt then return end
	charging, chargeT0, power = true, os.clock(), 0
	ui.shoot.BackgroundTransparency = 0.05
	updatePower()
end

function UI._release()
	if not charging then return end
	charging = false
	ui.shoot.BackgroundTransparency = T.btnAlpha
	if not active or sentAt then return end
	sentAt = os.clock()
	Remotes.get("SetPieceKick"):FireServer(aim.x, aim.y, math.max(power, 0.05), style, side)
	ui.hint.Text = "..."
end

-- one frame: aim movement + charge
function UI._tick(dt)
	if not active then return end
	local sx, sy = stickX, stickY
	local kx, ky = keyStick()
	local kl = math.sqrt(kx * kx + ky * ky)
	if kl > 0 then sx, sy = kx / kl, ky / kl end
	if math.sqrt(padX * padX + padY * padY) > 0.15 then sx, sy = padX, padY end
	local fine = charging and 0.5 or 1 -- a steadier aim while charging
	aim.x = math.clamp(aim.x + sx * AIM_SPEED_X * dt * fine, -1.3, 1.3)
	aim.y = math.clamp(aim.y + sy * AIM_SPEED_Y * dt * fine, 0, 1.3)
	updateReticle()
	if charging then
		power = math.clamp((os.clock() - chargeT0) / CHARGE_SECONDS, 0, 1)
		updatePower()
	end
	-- timer + resend guard
	local untilT = stateFolder and stateFolder:GetAttribute("SetPieceUntil")
	if untilT then
		ui.sub.Text = string.format("%s   -   %d s", (stateFolder:GetAttribute("SetPieceTeam") == "RED") and "AWAY" or "HOME", math.max(0, math.ceil(untilT - serverNow())))
	end
	if sentAt and os.clock() - sentAt > 1.5 then
		sentAt = nil -- the server did not take it (rate limit...): try again
		ui.hint.Text = "Stick - aim   |   hold SHOOT, release in the green zone"
	end
end

-- show / hide ---------------------------------------------------------------------------------------------------------

local function refresh()
	local taker = stateFolder:GetAttribute("SetPieceTaker")
	local mine = taker ~= nil and taker == player.UserId
	if mine == active then return end
	active = mine
	UI.Build()
	gui.Enabled = mine
	setBarVisible(not mine)
	if mine then
		local kind = stateFolder:GetAttribute("SetPieceKind")
		ui.title.Text = kind == "Penalty" and "PENALTY KICK" or "FREE KICK"
		local d = stateFolder:GetAttribute("SetPieceDist")
		ui.dist.Text = d and string.format("%d studs to goal", math.floor(d + 0.5)) or ""
		aim.x, aim.y = 0, (kind == "Penalty") and 0.3 or 0.4
		stickX, stickY, padX, padY, ringTouch = 0, 0, 0, 0, nil
		charging, power, sentAt = false, 0, nil
		ui.knob.Position = UDim2.fromScale(0.5, 0.5)
		ui.hint.Text = "Stick - aim   |   hold SHOOT, release in the green zone"
		setStyle("Normal")
		setSide(1)
		updateReticle()
		updatePower()
	else
		charging, sentAt = false, nil
	end
end

function UI.IsActive()
	return active
end

function UI.Init()
	stateFolder = ReplicatedStorage:WaitForChild("SoccerState", 15)
	if not stateFolder then return end
	UI.Build()
	stateFolder:GetAttributeChangedSignal("SetPieceTaker"):Connect(refresh)
	RunService.RenderStepped:Connect(function(dt)
		UI._tick(dt)
	end)
	refresh()
end

UI._state = function() return { aim = aim, style = style, side = side, power = power, active = active } end
UI._setAim = function(x, y) aim.x, aim.y = x, y end
UI._setStick = function(x, y) stickX, stickY = x, y end

return UI
