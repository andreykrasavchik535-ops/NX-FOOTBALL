--[[ SoccerClient/MainMenu v3 — original PES-Master-League-inspired NX26 design.
	 Deep navy translucent panels, white typography, restrained light-blue accents,
	 featured KICK OFF card, static matchday rail, adaptive control-hints footer.
	 The 3D stadium (MenuCamera) shows behind the UI. API unchanged:
	 Build(parent,{KickOff,Settings,Toast}), Show, Hide, IsVisible. ]]
local TweenService = game:GetService("TweenService")
local UserInputService = game:GetService("UserInputService")
local Workspace = game:GetService("Workspace")
local UIKit = require(script.Parent:WaitForChild("UIKit"))
local SoundController = require(script.Parent:WaitForChild("SoundController"))
local MainMenu = {}
local P = {
	panel = Color3.fromRGB(12, 18, 29), panel2 = Color3.fromRGB(19, 27, 42),
	row = Color3.fromRGB(15, 22, 35), rowSel = Color3.fromRGB(30, 43, 64),
	stroke = Color3.fromRGB(66, 86, 118), text = Color3.fromRGB(242, 247, 255),
	dim = Color3.fromRGB(150, 166, 192), accent = Color3.fromRGB(88, 172, 255),
	locked = Color3.fromRGB(110, 122, 144),
}
local ITEMS = {
	{ id = "kickoff", title = "KICK OFF", sub = "Quick match", icon = "ball", soon = false, desc = "Jump straight into a match. Choose your club, set the formation and kick off." },
	{ id = "ultimate", title = "ULTIMATE TEAM", sub = "Coming soon", icon = "cards", soon = true, desc = "Build and manage your dream squad. This mode is in development." },
	{ id = "career", title = "CAREER", sub = "Coming soon", icon = "trophy", soon = true, desc = "Take a club through the seasons. This mode is in development." },
	{ id = "clubs", title = "CLUBS", sub = "Coming soon", icon = "shield", soon = true, desc = "Browse clubs, kits and stadiums. This mode is in development." },
	{ id = "settings", title = "SETTINGS", sub = "Audio / Camera / Controls", icon = "sliders", soon = false, desc = "Tune audio, camera, sensitivity, key bindings and graphics." },
}
local gui, root, visible, selection = nil, nil, false, 1
local callbacks, rows, sections, conns = {}, {}, {}, {}
local featuredInner, spinTarget, resizeConn, lastVP
local function tw(o, props, t) TweenService:Create(o, TweenInfo.new(t or 0.2, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), props):Play() end
local function new(class, props, parent)
	local o = Instance.new(class)
	for k, v in pairs(props or {}) do o[k] = v end
	if parent then o.Parent = parent end
	return o
end
local function corner(o, r) new("UICorner", { CornerRadius = r or UDim.new(0, 10) }, o) end
local function stroke(o, c, t, tr) new("UIStroke", { Color = c or P.stroke, Thickness = t or 1, Transparency = tr or 0, ApplyStrokeMode = Enum.ApplyStrokeMode.Border }, o) end
local function label(parent, props)
	local l = new("TextLabel", { BackgroundTransparency = 1, Font = Enum.Font.Gotham, TextColor3 = P.text, TextSize = 16, TextXAlignment = Enum.TextXAlignment.Left }, parent)
	for k, v in pairs(props or {}) do l[k] = v end
	return l
end
local function connect(sig, fn) local c = sig:Connect(fn); table.insert(conns, c); return c end
local function icon(parent, kind, s, color)
	local f = new("Frame", { BackgroundTransparency = 1, Size = UDim2.fromOffset(s, s) }, parent)
	local c = color or P.text
	if kind == "ball" then
		local ball = new("Frame", { BackgroundColor3 = c, Size = UDim2.fromScale(0.86, 0.86), Position = UDim2.fromScale(0.07, 0.07) }, f)
		corner(ball, UDim.new(1, 0))
		for _, pos in ipairs({ {0.42,0.40},{0.24,0.30},{0.62,0.30},{0.30,0.62},{0.58,0.62} }) do
			local patch = new("Frame", { BackgroundColor3 = P.panel, Size = UDim2.fromScale(0.16, 0.16), Position = UDim2.fromScale(pos[1], pos[2]) }, ball)
			corner(patch, UDim.new(1, 0))
		end
	elseif kind == "cards" then
		local a = new("Frame", { BackgroundColor3 = c, BackgroundTransparency = 0.35, Size = UDim2.fromScale(0.5, 0.66), Position = UDim2.fromScale(0.16, 0.12), Rotation = -8 }, f); corner(a, UDim.new(0, 4))
		local b = new("Frame", { BackgroundColor3 = c, Size = UDim2.fromScale(0.5, 0.66), Position = UDim2.fromScale(0.36, 0.22), Rotation = 8 }, f); corner(b, UDim.new(0, 4))
	elseif kind == "trophy" then
		local cup = new("Frame", { BackgroundColor3 = c, Size = UDim2.fromScale(0.5, 0.42), Position = UDim2.fromScale(0.25, 0.12) }, f); corner(cup, UDim.new(0, 6))
		new("Frame", { BackgroundColor3 = c, Size = UDim2.fromScale(0.12, 0.2), Position = UDim2.fromScale(0.44, 0.52) }, f)
		local base = new("Frame", { BackgroundColor3 = c, Size = UDim2.fromScale(0.4, 0.12), Position = UDim2.fromScale(0.3, 0.72) }, f); corner(base, UDim.new(0, 3))
	elseif kind == "shield" then
		local sh = new("Frame", { BackgroundColor3 = c, Size = UDim2.fromScale(0.6, 0.62), Position = UDim2.fromScale(0.2, 0.14) }, f); corner(sh, UDim.new(0, 8))
		local tip = new("Frame", { BackgroundColor3 = c, Size = UDim2.fromScale(0.3, 0.3), Position = UDim2.fromScale(0.35, 0.58), Rotation = 45 }, f); corner(tip, UDim.new(0, 4))
	elseif kind == "sliders" then
		for i = 1, 3 do
			local y = 0.2 + (i - 1) * 0.26
			local line = new("Frame", { BackgroundColor3 = c, BackgroundTransparency = 0.3, Size = UDim2.fromScale(0.72, 0.06), Position = UDim2.fromScale(0.14, y) }, f); corner(line, UDim.new(1, 0))
			local kx = (i == 2) and 0.5 or 0.28
			local knob = new("Frame", { BackgroundColor3 = c, Size = UDim2.fromScale(0.14, 0.14), Position = UDim2.fromScale(kx, y - 0.04) }, f); corner(knob, UDim.new(1, 0))
		end
	end
	return f
end
local function buildFeaturedContent(index)
	if not featuredInner then return end
	for _, ch in ipairs(featuredInner:GetChildren()) do ch:Destroy() end
	local item = ITEMS[index]
	local u = UIKit.unit()
	spinTarget = nil
	if item.id == "kickoff" then
		local circle = new("Frame", { BackgroundTransparency = 1, Size = UDim2.fromOffset(u * 3.2, u * 3.2), Position = UDim2.fromScale(0.8, 0.5), AnchorPoint = Vector2.new(0.5, 0.5) }, featuredInner)
		corner(circle, UDim.new(1, 0)); stroke(circle, P.accent, 1.5, 0.7)
		new("Frame", { BackgroundColor3 = P.accent, BackgroundTransparency = 0.75, Size = UDim2.new(0, 1.5, 1, 0), Position = UDim2.fromScale(0.8, 0), AnchorPoint = Vector2.new(0.5, 0) }, featuredInner)
		local ball = icon(featuredInner, "ball", math.floor(u * 1.5), P.text)
		ball.Position = UDim2.fromScale(0.8, 0.5); ball.AnchorPoint = Vector2.new(0.5, 0.5)
		spinTarget = ball
		TweenService:Create(ball, TweenInfo.new(16, Enum.EasingStyle.Linear, Enum.EasingDirection.InOut, -1, false), { Rotation = 360 }):Play()
	end
	local ic = icon(featuredInner, item.icon, math.floor(u * 0.7), item.soon and P.locked or P.accent)
	ic.Position = UDim2.fromOffset(u * 0.4, u * 0.4)
	label(featuredInner, { Text = item.title, Font = Enum.Font.GothamBold, TextSize = math.floor(u * 0.6), TextColor3 = item.soon and P.dim or P.text, Position = UDim2.fromOffset(u * 0.4, u * 1.3), Size = UDim2.new(1, -u * 0.8, 0, u * 0.8) })
	label(featuredInner, { Text = item.desc, TextSize = math.floor(u * 0.26), TextColor3 = P.dim, TextWrapped = true, Position = UDim2.fromOffset(u * 0.4, u * 2.15), Size = UDim2.new(0.6, 0, 0, u * 1.2) })
	if item.soon then
		local badge = new("Frame", { BackgroundColor3 = P.panel2, Size = UDim2.fromOffset(u * 2.4, u * 0.5), Position = UDim2.fromOffset(u * 0.4, u * 3.5) }, featuredInner)
		corner(badge, UDim.new(0, 6)); stroke(badge, P.locked, 1, 0.3)
		label(badge, { Text = "COMING SOON", Font = Enum.Font.GothamMedium, TextSize = math.floor(u * 0.22), TextColor3 = P.locked, Size = UDim2.fromScale(1, 1), TextXAlignment = Enum.TextXAlignment.Center })
	else
		label(featuredInner, { Text = (UIKit.hasKeyboard() and "Enter / A" or "Tap") .. " to continue", Font = Enum.Font.GothamMedium, TextSize = math.floor(u * 0.24), TextColor3 = P.accent, Position = UDim2.fromOffset(u * 0.4, u * 3.5), Size = UDim2.new(1, -u * 0.8, 0, u * 0.5) })
	end
end
local function setSelection(i, silent)
	selection = ((i - 1) % #ITEMS) + 1
	for idx, r in ipairs(rows) do
		local sel = (idx == selection)
		tw(r.btn, { BackgroundColor3 = sel and P.rowSel or P.row, BackgroundTransparency = sel and 0.05 or 0.45 }, 0.16)
		tw(r.bar, { BackgroundTransparency = sel and 0 or 1 }, 0.16)
	end
	if featuredInner then
		featuredInner.GroupTransparency = 1
		buildFeaturedContent(selection)
		tw(featuredInner, { GroupTransparency = 0 }, 0.22)
	end
	if not silent then SoundController.Hover() end
end
local function activate(i)
	local item = ITEMS[i]; if not item then return end
	SoundController.Click()
	if item.soon then if callbacks.Toast then callbacks.Toast("info", item.title .. " — COMING SOON") end; return end
	if item.id == "kickoff" and callbacks.KickOff then callbacks.KickOff()
	elseif item.id == "settings" and callbacks.Settings then callbacks.Settings() end
end
local function makeRow(parent, item, index, u, rowH)
	local btn = new("TextButton", { Text = "", AutoButtonColor = false, BackgroundColor3 = P.row, BackgroundTransparency = 0.45, Size = UDim2.new(1, 0, 0, rowH), LayoutOrder = index }, parent)
	corner(btn, UDim.new(0, 10)); stroke(btn, item.id == "kickoff" and P.accent or P.stroke, item.id == "kickoff" and 1.4 or 1, item.id == "kickoff" and 0.35 or 0.6)
	local bar = new("Frame", { BackgroundColor3 = P.accent, BackgroundTransparency = 1, Size = UDim2.new(0, 4, 0.62, 0), Position = UDim2.new(0, 8, 0.19, 0) }, btn); corner(bar, UDim.new(1, 0))
	local ic = icon(btn, item.icon, math.floor(rowH * 0.5), item.soon and P.locked or P.text)
	ic.Position = UDim2.new(0, u * 0.32, 0.5, 0); ic.AnchorPoint = Vector2.new(0, 0.5)
	local tx = u * 0.32 + rowH * 0.5 + u * 0.22
	label(btn, { Text = item.title, Font = Enum.Font.GothamMedium, TextSize = math.floor(rowH * 0.3), TextColor3 = item.soon and P.dim or P.text, Position = UDim2.new(0, tx, 0.16, 0), Size = UDim2.new(1, -(tx + u * 0.3), 0, rowH * 0.4) })
	label(btn, { Text = item.soon and "COMING SOON" or item.sub, TextSize = math.floor(rowH * 0.2), TextColor3 = item.soon and P.locked or P.dim, Position = UDim2.new(0, tx, 0.56, 0), Size = UDim2.new(1, -(tx + u * 0.3), 0, rowH * 0.3) })
	rows[index] = { btn = btn, bar = bar }
	connect(btn.Activated, function() setSelection(index, true); activate(index) end)
	connect(btn.MouseEnter, function() if not UIKit.isMobile() and visible then setSelection(index) end end)
	return btn
end
local function clear()
	for _, c in ipairs(conns) do pcall(function() c:Disconnect() end) end
	conns = {}
	if resizeConn then resizeConn:Disconnect(); resizeConn = nil end
	if root then root:Destroy(); root = nil end
	rows = {}; sections = {}; featuredInner = nil; spinTarget = nil
end
local function build()
	clear()
	local cam = Workspace.CurrentCamera
	local vp = cam and cam.ViewportSize or Vector2.new(1280, 720)
	lastVP = vp
	local mobile = UIKit.isMobile() or vp.X < 760
	local u = UIKit.unit()
	root = new("CanvasGroup", { Name = "MainMenu", Size = UDim2.fromScale(1, 1), BackgroundTransparency = 1, Visible = false }, gui)
	local bg = new("Frame", { Size = UDim2.fromScale(1, 1), BackgroundColor3 = Color3.new(0, 0, 0), BackgroundTransparency = 0.25, ZIndex = 1 }, root)
	new("UIGradient", { Rotation = 0, Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.05), NumberSequenceKeypoint.new(0.45, 0.45), NumberSequenceKeypoint.new(1, 0.8) }) }, bg)
	local header = new("CanvasGroup", { BackgroundTransparency = 1, Position = UDim2.fromOffset(math.floor(u * 0.6), math.floor(u * 0.5)), Size = UDim2.fromOffset(u * 7, u * 2), ZIndex = 3 }, root)
	label(header, { Text = "NX26", Font = Enum.Font.GothamBlack, TextSize = math.floor(u * 1.3), TextColor3 = P.text, Size = UDim2.fromOffset(u * 7, u * 1.2), TextStrokeTransparency = 0.7 })
	label(header, { Text = "N E X T   F O O T B A L L", Font = Enum.Font.GothamMedium, TextSize = math.floor(u * 0.28), TextColor3 = P.accent, Position = UDim2.fromOffset(2, u * 1.25), Size = UDim2.fromOffset(u * 7, u * 0.4) })
	local underline = new("Frame", { BackgroundColor3 = P.accent, Size = UDim2.fromOffset(u * 1.6, 3), Position = UDim2.fromOffset(2, u * 1.75) }, header); corner(underline, UDim.new(1, 0))
	table.insert(sections, header)
	local navW = mobile and math.min(vp.X - u * 1.2, u * 7) or math.clamp(vp.X * 0.3, u * 5, u * 7.5)
	local rowH = math.clamp(u * 0.95, 52, 78)
	local gap = math.floor(u * 0.16)
	local navH = #ITEMS * rowH + (#ITEMS - 1) * gap + u * 0.6
	local navX = mobile and (vp.X - navW) / 2 or math.floor(u * 0.6)
	local navY = mobile and (vp.Y - navH) / 2 + u * 0.6 or math.floor(u * 2.9)
	local nav = new("CanvasGroup", { BackgroundColor3 = P.panel, BackgroundTransparency = 0.18, Position = UDim2.fromOffset(navX, navY), Size = UDim2.fromOffset(navW, navH), ZIndex = 3 }, root)
	corner(nav, UDim.new(0, 14)); stroke(nav, P.stroke, 1.2, 0.5)
	new("UIPadding", { PaddingTop = UDim.new(0, math.floor(u * 0.3)), PaddingBottom = UDim.new(0, math.floor(u * 0.3)), PaddingLeft = UDim.new(0, math.floor(u * 0.3)), PaddingRight = UDim.new(0, math.floor(u * 0.3)) }, nav)
	new("UIListLayout", { Padding = UDim.new(0, gap), SortOrder = Enum.SortOrder.LayoutOrder }, nav)
	for i, item in ipairs(ITEMS) do makeRow(nav, item, i, u, rowH) end
	table.insert(sections, nav)
	local fx, fw
	if not mobile then
		fx = navX + navW + math.floor(u * 0.5)
		fw = math.clamp(vp.X * 0.34, u * 5, u * 9)
		local featured = new("CanvasGroup", { BackgroundColor3 = P.panel2, BackgroundTransparency = 0.12, Position = UDim2.fromOffset(fx, navY), Size = UDim2.fromOffset(fw, navH), ZIndex = 3 }, root)
		corner(featured, UDim.new(0, 14)); stroke(featured, P.stroke, 1.2, 0.5)
		new("UIGradient", { Rotation = 135, Color = ColorSequence.new(P.panel2, P.panel) }, featured)
		featuredInner = new("CanvasGroup", { BackgroundTransparency = 1, Size = UDim2.fromScale(1, 1) }, featured)
		table.insert(sections, featured)
		if vp.X > 1180 then
			local rx = fx + fw + math.floor(u * 0.5)
			local rw = vp.X - rx - math.floor(u * 0.6)
			if rw > u * 3 then
				local rail = new("CanvasGroup", { BackgroundTransparency = 1, Position = UDim2.fromOffset(rx, navY), Size = UDim2.fromOffset(rw, navH), ZIndex = 3 }, root)
				local news = new("Frame", { BackgroundColor3 = P.panel, BackgroundTransparency = 0.18, Size = UDim2.new(1, 0, 0.56, 0) }, rail); corner(news, UDim.new(0, 12)); stroke(news, P.stroke, 1, 0.55)
				label(news, { Text = "MATCHDAY", Font = Enum.Font.GothamBold, TextSize = math.floor(u * 0.26), TextColor3 = P.accent, Position = UDim2.fromOffset(u * 0.3, u * 0.25), Size = UDim2.new(1, -u * 0.6, 0, u * 0.4) })
				label(news, { Text = "Welcome to NX26 Next Football.", TextSize = math.floor(u * 0.22), TextColor3 = P.text, TextWrapped = true, Position = UDim2.fromOffset(u * 0.3, u * 0.75), Size = UDim2.new(1, -u * 0.6, 0, u * 0.7) })
				label(news, { Text = "Kick Off to start a match with your club.", TextSize = math.floor(u * 0.2), TextColor3 = P.dim, TextWrapped = true, Position = UDim2.fromOffset(u * 0.3, u * 1.5), Size = UDim2.new(1, -u * 0.6, 0, u * 0.7) })
				local about = new("Frame", { BackgroundColor3 = P.panel, BackgroundTransparency = 0.18, Position = UDim2.new(0, 0, 0.6, 0), Size = UDim2.new(1, 0, 0.4, 0) }, rail); corner(about, UDim.new(0, 12)); stroke(about, P.stroke, 1, 0.55)
				label(about, { Text = "ABOUT", Font = Enum.Font.GothamBold, TextSize = math.floor(u * 0.24), TextColor3 = P.accent, Position = UDim2.fromOffset(u * 0.3, u * 0.25), Size = UDim2.new(1, -u * 0.6, 0, u * 0.4) })
				label(about, { Text = "NX26 Next Football · v3.0 · Community build", TextSize = math.floor(u * 0.2), TextColor3 = P.dim, TextWrapped = true, Position = UDim2.fromOffset(u * 0.3, u * 0.7), Size = UDim2.new(1, -u * 0.6, 1, -u * 0.9) })
				table.insert(sections, rail)
			end
		end
	end
	local hint = UIKit.isMobile() and "Tap a mode to continue" or "Up / Down  Navigate      Enter / A  Select"
	local footer = new("CanvasGroup", { BackgroundColor3 = P.panel, BackgroundTransparency = 0.3, AnchorPoint = Vector2.new(0.5, 1), Position = UDim2.new(0.5, 0, 1, -math.floor(u * 0.3)), Size = UDim2.fromOffset(math.min(vp.X - u, u * 9), u * 0.6), ZIndex = 3 }, root)
	corner(footer, UDim.new(0, 10)); stroke(footer, P.stroke, 1, 0.6)
	label(footer, { Text = hint, Font = Enum.Font.GothamMedium, TextSize = math.floor(u * 0.22), TextColor3 = P.dim, Size = UDim2.fromScale(1, 1), TextXAlignment = Enum.TextXAlignment.Center })
	table.insert(sections, footer)
	connect(UserInputService.InputBegan, function(input, processed)
		if not visible or processed then return end
		local k = input.KeyCode
		if k == Enum.KeyCode.Up or k == Enum.KeyCode.DPadUp then setSelection(selection - 1)
		elseif k == Enum.KeyCode.Down or k == Enum.KeyCode.DPadDown then setSelection(selection + 1)
		elseif k == Enum.KeyCode.Return or k == Enum.KeyCode.ButtonA then activate(selection) end
	end)
	if cam then
		resizeConn = cam:GetPropertyChangedSignal("ViewportSize"):Connect(function()
			local nvp = cam.ViewportSize
			if math.abs(nvp.X - lastVP.X) > 40 or math.abs(nvp.Y - lastVP.Y) > 40 then
				local wasVisible = visible
				build(); setSelection(selection, true)
				if wasVisible then MainMenu.Show() end
			end
		end)
	end
	setSelection(selection, true)
end
function MainMenu.Build(parent, cb) gui = parent; callbacks = cb or {}; build(); return root end
function MainMenu.Show()
	if not root then return end
	visible = true; root.Visible = true; root.GroupTransparency = 1
	tw(root, { GroupTransparency = 0 }, 0.3)
	for i, sec in ipairs(sections) do
		sec.GroupTransparency = 1
		TweenService:Create(sec, TweenInfo.new(0.35, Enum.EasingStyle.Quad, Enum.EasingDirection.Out, 0, false, (i - 1) * 0.06), { GroupTransparency = 0 }):Play()
	end
end
function MainMenu.Hide() visible = false; if root then root.Visible = false end end
function MainMenu.IsVisible() return visible end
return MainMenu
