local SoundService = game:GetService("SoundService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Shared = ReplicatedStorage:WaitForChild("SoccerShared")
local Remotes = require(Shared:WaitForChild("Remotes"))
local SoundIds = require(Shared:WaitForChild("SoundIds"))
local SoundController = {}
local vol = { Master = 0.8, SFX = 0.8, Crowd = 0.5, Music = 0.6 }
local function ensureUI()
	local g = SoundService:FindFirstChild("NXUI")
	if not g then g = Instance.new("SoundGroup"); g.Name = "NXUI"; g.Parent = SoundService end
	return g
end
local function applyVolumes()
	ensureUI().Volume = vol.Master * vol.SFX
	local w = SoundService:FindFirstChild("NXWorld"); if w then w.Volume = vol.Master * vol.SFX end
	local c = SoundService:FindFirstChild("NXCrowd"); if c then c.Volume = vol.Master * vol.Crowd end
end
local function oneShot(name, groupName)
	local s = SoundIds.Resolve(name); if not s then return end
	s.Looped = false
	s.SoundGroup = (groupName == "NXUI") and ensureUI() or (SoundService:FindFirstChild(groupName) or ensureUI())
	s.Parent = SoundService; s:Play()
	s.Ended:Connect(function() s:Destroy() end)
	task.delay(6, function() if s.Parent then s:Destroy() end end)
end
function SoundController.Click() oneShot("UIClick", "NXUI") end
function SoundController.Hover() oneShot("UIHover", "NXUI") end
function SoundController.SetVolumes(v)
	if type(v) == "table" then for k, x in pairs(v) do if type(x) == "number" then vol[k] = x end end end
	applyVolumes()
end
function SoundController.Init()
	applyVolumes()
	SoundService.ChildAdded:Connect(function(ch)
		if ch:IsA("SoundGroup") and (ch.Name == "NXWorld" or ch.Name == "NXCrowd") then task.defer(applyVolumes) end
	end)
	Remotes.get("TackleApproved").OnClientEvent:Connect(function() oneShot("Tackle", "NXWorld") end)
end
return SoundController
