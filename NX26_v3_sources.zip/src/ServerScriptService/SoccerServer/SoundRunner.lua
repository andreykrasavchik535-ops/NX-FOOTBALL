local ReplicatedStorage = game:GetService("ReplicatedStorage")
local SoundService = game:GetService("SoundService")
local RunService = game:GetService("RunService")
local Shared = ReplicatedStorage:WaitForChild("SoccerShared")
local SoundIds = require(Shared:WaitForChild("SoundIds"))
local BallService = require(script.Parent:WaitForChild("BallService"))
local GoalkeeperService = require(script.Parent:WaitForChild("GoalkeeperService"))
local SoundRunner = {}
local lastPost = 0
local crowdSound, crowdConn
local function ensureGroup(name)
	local g = SoundService:FindFirstChild(name)
	if not g then g = Instance.new("SoundGroup"); g.Name = name; g.Parent = SoundService end
	return g
end
local function playAtBall(name)
	local ball = BallService.GetBall(); if not ball then return end
	local s = SoundIds.Resolve(name); if not s then return end
	s.Looped = false; s.SoundGroup = ensureGroup("NXWorld"); s.RollOffMinDistance = 12; s.RollOffMaxDistance = 260
	s.Parent = ball; s:Play()
	s.Ended:Connect(function() s:Destroy() end)
	task.delay(6, function() if s.Parent then s:Destroy() end end)
end
local function playGlobal(name)
	local s = SoundIds.Resolve(name); if not s then return end
	s.Looped = false; s.SoundGroup = ensureGroup("NXWorld"); s.Parent = SoundService; s:Play()
	s.Ended:Connect(function() s:Destroy() end)
	task.delay(8, function() if s.Parent then s:Destroy() end end)
end
local function isPostPart(part)
	local n = part.Name
	return string.sub(n, 1, 4) == "Post" or string.sub(n, 1, 3) == "Bar"
end
local function startCrowd()
	if crowdSound then return end
	local s = SoundIds.Resolve("Crowd"); if not s then return end
	s.Looped = false; s.SoundGroup = ensureGroup("NXCrowd"); s.Parent = SoundService; crowdSound = s; s:Play()
	s.Ended:Connect(function() if crowdSound == s and s.Parent then s.TimePosition = 0; s:Play() end end)
	crowdConn = RunService.Heartbeat:Connect(function()
		if crowdSound ~= s or not s.Parent then if crowdConn then crowdConn:Disconnect(); crowdConn = nil end; return end
		local len = s.TimeLength
		if len > 4 and s.IsPlaying and s.TimePosition >= len - 2 then s.TimePosition = 0 end
	end)
end
function SoundRunner.Init()
	ensureGroup("NXWorld"); ensureGroup("NXCrowd")
	BallService.OnKick = function(_, kind) if kind == "PASS" then playAtBall("Pass") else playAtBall("Kick") end end
	local origCatch = GoalkeeperService.OnCatch
	GoalkeeperService.OnCatch = function(player, now) if origCatch then origCatch(player, now) end; playAtBall("Save") end
	local origParry = GoalkeeperService.OnParry
	GoalkeeperService.OnParry = function(player, now) if origParry then origParry(player, now) end; playAtBall("Save") end
	local stateFolder = ReplicatedStorage:WaitForChild("SoccerState", 20)
	if stateFolder then
		stateFolder:GetAttributeChangedSignal("State"):Connect(function()
			local st = stateFolder:GetAttribute("State")
			if st == "GoalPause" then playGlobal("Goal"); task.delay(0.5, function() playGlobal("Whistle") end)
			elseif st == "Kickoff" or st == "HalfTime" or st == "Results" then playGlobal("Whistle") end
		end)
	end
	task.spawn(function()
		local ball = BallService.GetBall()
		while not ball do task.wait(0.5); ball = BallService.GetBall() end
		ball.Touched:Connect(function(part)
			if isPostPart(part) then local now = os.clock(); if now - lastPost >= 0.25 then lastPost = now; playAtBall("Post") end end
		end)
	end)
	startCrowd()
end
return SoundRunner
