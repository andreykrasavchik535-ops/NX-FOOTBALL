--[[
	ServerScriptService/SoccerServer/SetPieceService (ModuleScript)
	Free kicks and penalties.
	  * MatchService calls SetPiece.Start(kind, team, spotWorld) after a foul.
	  * The taker is put behind the ball (frozen in place), the opponents are moved away (wall distance / out of the box).
	  * The taker aims with the on-screen JOYSTICK (client SetPieceUI) and sends SetPieceKick(aimX, aimY, power, style, side).
	    aimX -1..1 = left..right post, aimY 0..1 = ground..crossbar (values a bit outside miss the goal).
	  * The server turns the aim into a real kick (ballistic arc to that point of the goal), so it is never trusted blindly.
	State shared with the clients (ReplicatedStorage.SoccerState attributes):
	  SetPieceKind / SetPieceTeam / SetPieceTaker (userId) / SetPieceUntil (server time) / SetPieceGoal / SetPieceRight
	  SetPieceHalfW / SetPieceHeight / SetPieceDist
]]
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Workspace = game:GetService("Workspace")

local Shared = ReplicatedStorage:WaitForChild("SoccerShared")
local Config = require(Shared:WaitForChild("Config"))
local Util = require(Shared:WaitForChild("Util"))
local Remotes = require(Shared:WaitForChild("Remotes"))

local S = script.Parent
local FieldService = require(S:WaitForChild("FieldService"))
local TeamService = require(S:WaitForChild("TeamService"))
local BallService = require(S:WaitForChild("BallService"))

local SetPiece = {}

local stateFolder
local active = nil -- { kind, team, taker, goalPos, right, spot, untilT, token }
local bucket = {}
local STYLES = { Normal = true, Finesse = true, Trivela = true, Knuckle = true }

local function serverNow()
	local ok, t = pcall(function()
		return Workspace:GetServerTimeNow()
	end)
	return ok and t or os.time()
end

local ATTRS = {
	"SetPieceKind", "SetPieceTeam", "SetPieceTaker", "SetPieceUntil", "SetPieceGoal", "SetPieceRight",
	"SetPieceHalfW", "SetPieceHeight", "SetPieceDist",
}

local function setAttr(name, v)
	if stateFolder then
		stateFolder:SetAttribute(name, v)
	end
end

local function clearAttrs()
	for _, n in ipairs(ATTRS) do
		setAttr(n, nil)
	end
end

local function unfreeze(player)
	local _, _, hrp = Util.getCharParts(player)
	if hrp then
		hrp.Anchored = false
	end
	if player and player.Character then
		local hrp2 = player.Character:FindFirstChild("HumanoidRootPart")
		if hrp2 then
			hrp2.Anchored = false
		end
	end
end

function SetPiece.IsActive()
	return active ~= nil
end

function SetPiece.GetTaker()
	return active and active.taker or nil
end

function SetPiece.End(why)
	if not active then
		return
	end
	local a = active
	active = nil
	unfreeze(a.taker)
	clearAttrs()
	BallService.ClearRestart()
	if why ~= "reset" then
		BallService.SetRestart(a.team, 2.5) -- the kicker's team keeps the ball for a moment
	end
end

-- Geometry -------------------------------------------------------------------------------------------------------

-- Goal that the given team attacks: its centre on the goal line (world), the direction along the line, the local z sign.
local function attackedGoal(team)
	local f = FieldService.Get()
	local sign = -TeamService.GetDefendSign(team) -- the team defends sign, so it attacks -sign
	local center = FieldService.ToWorld(Vector3.new(0, 0, sign * f.halfL))
	local right = FieldService.DirToWorld(Vector3.new(1, 0, 0))
	-- "right" must be the taker's right hand side when he looks at the goal
	local look = FieldService.DirToWorld(Vector3.new(0, 0, sign))
	if look:Cross(Vector3.new(0, 1, 0)):Dot(right) < 0 then
		right = -right
	end
	return Vector3.new(center.X, f.ground, center.Z), right.Unit, sign
end
SetPiece._attackedGoal = attackedGoal

local function freezeAt(player, pos, lookAt)
	local char, hum, hrp = Util.getCharParts(player)
	if not hrp then
		return false
	end
	local f = FieldService.Get()
	local p = Vector3.new(pos.X, f.ground + Util.hipOffset(hum, hrp) + 0.25, pos.Z)
	char:PivotTo(CFrame.lookAt(p, Vector3.new(lookAt.X, p.Y, lookAt.Z)))
	hrp.AssemblyLinearVelocity = Vector3.zero
	return true
end

local function pushAway(player, spot, radius, towardsFallback)
	local char, hum, hrp = Util.getCharParts(player)
	if not hrp then
		return
	end
	local off = Vector3.new(hrp.Position.X - spot.X, 0, hrp.Position.Z - spot.Z)
	if off.Magnitude >= radius then
		return
	end
	local dir = off.Magnitude > 0.5 and off.Unit or towardsFallback
	local f = FieldService.Get()
	local p = spot + dir * radius
	char:PivotTo(CFrame.lookAt(Vector3.new(p.X, f.ground + Util.hipOffset(hum, hrp) + 0.25, p.Z), Vector3.new(spot.X, f.ground + 3, spot.Z)))
	hrp.AssemblyLinearVelocity = Vector3.zero
end

-- Start ----------------------------------------------------------------------------------------------------------

local function chooseTaker(team, spot)
	local best, bestD
	for _, p in ipairs(TeamService.GetMembers(team)) do
		local _, _, hrp = Util.getCharParts(p)
		if hrp and TeamService.GetRole(p) ~= "GK" then
			local d = (hrp.Position - spot).Magnitude
			if not bestD or d < bestD then
				best, bestD = p, d
			end
		end
	end
	if not best then -- a team made only of a goalkeeper: he takes it
		for _, p in ipairs(TeamService.GetMembers(team)) do
			if Util.getCharParts(p) then
				return p
			end
		end
	end
	return best
end

-- kind: "FreeKick" | "Penalty"; team = the team that TAKES the kick; spot = world position of the ball
function SetPiece.Start(kind, team, spot, takerOverride)
	if active then
		SetPiece.End("reset")
	end
	local f = FieldService.Get()
	local goalPos, right, sign = attackedGoal(team)
	if kind == "Penalty" then
		local lp = Vector3.new(0, 0, sign * (f.halfL - f.penaltyDepth * (Config.PENALTY_SPOT_FRACTION or 0.62)))
		spot = FieldService.ToWorld(lp)
	end
	spot = Vector3.new(spot.X, f.ground + Config.BALL_DIAMETER / 2 + 0.05, spot.Z)
	local taker = takerOverride or chooseTaker(team, spot)
	if not taker then
		return false
	end
	local other = TeamService.Other(team)

	BallService.ClearRestart()
	BallService.PlaceAt(spot, 0.4)
	BallService.SetRestart(team, (Config.SETPIECE_SECONDS or 20) + 3)

	-- opponents / everybody else get out of the way
	local toGoal = Vector3.new(goalPos.X - spot.X, 0, goalPos.Z - spot.Z)
	toGoal = toGoal.Magnitude > 0.1 and toGoal.Unit or Vector3.new(0, 0, 1)
	if kind == "Penalty" then
		local lineZ = sign * (f.halfL - f.penaltyDepth - 8) -- just outside the box
		local n = 0
		for _, p in ipairs(Players:GetPlayers()) do
			local t = TeamService.GetTeam(p)
			if t and p ~= taker then
				local isKeeper = (t == other and TeamService.GetRole(p) == "GK")
				if not isKeeper then
					n = n + 1
					local x = ((n % 2 == 0) and 1 or -1) * (14 + math.floor(n / 2) * 9)
					freezeAt(p, FieldService.ToWorld(Vector3.new(x, 0, lineZ)), spot)
				end
			end
		end
	else
		for _, p in ipairs(TeamService.GetMembers(other)) do
			if TeamService.GetRole(p) ~= "GK" then
				pushAway(p, spot, Config.FREEKICK_WALL_DISTANCE or 28, -toGoal)
			end
		end
	end
	-- the taker stands behind the ball and looks at the goal
	local behind = spot - toGoal * (kind == "Penalty" and 5 or 4)
	freezeAt(taker, behind, goalPos)
	local _, _, thrp = Util.getCharParts(taker)
	if thrp then
		thrp.Anchored = true
	end

	local token = {}
	active = {
		kind = kind, team = team, taker = taker, goalPos = goalPos, right = right, spot = spot, token = token,
		untilT = os.clock() + (Config.SETPIECE_SECONDS or 20),
	}
	setAttr("SetPieceKind", kind)
	setAttr("SetPieceTeam", team)
	setAttr("SetPieceGoal", goalPos)
	setAttr("SetPieceRight", right)
	setAttr("SetPieceHalfW", f.goalHalfW)
	setAttr("SetPieceHeight", f.goalH)
	setAttr("SetPieceDist", (Vector3.new(goalPos.X, 0, goalPos.Z) - Vector3.new(spot.X, 0, spot.Z)).Magnitude)
	setAttr("SetPieceUntil", serverNow() + (Config.SETPIECE_SECONDS or 20))
	setAttr("SetPieceTaker", taker.UserId) -- last: the client reacts to this one

	Remotes.get("Notify"):FireAllClients("info", (kind == "Penalty" and "PENALTY" or "FREE KICK") .. " - " .. (team == "RED" and "AWAY" or "HOME"))

	task.delay((Config.SETPIECE_SECONDS or 20) + 0.2, function()
		if active and active.token == token then
			SetPiece.End("timeout")
		end
	end)
	return true
end

-- The kick -------------------------------------------------------------------------------------------------------

local function num(v, lo, hi, default)
	if type(v) ~= "number" or v ~= v or v == math.huge or v == -math.huge then
		return default
	end
	return math.clamp(v, lo, hi)
end

local function rotXZ(x, z, a) -- same rotation convention as BallService.applyCurve
	local c, sn = math.cos(a), math.sin(a)
	return x * c - z * sn, x * sn + z * c
end

-- Pure calculation (also used by the tests): returns dir (unit, flat), hSpeed, vSpeed, curve
function SetPiece.Compute(a, ballPos, ax, ay, power, style, side)
	local st = Config.SHOT_STYLES[style] or Config.SHOT_STYLES.Normal
	local f = FieldService.Get()
	local target = a.goalPos + a.right * (ax * f.goalHalfW) + Vector3.new(0, ay * f.goalH, 0)
	local flatTo = Vector3.new(target.X - ballPos.X, 0, target.Z - ballPos.Z)
	local dist = math.max(flatTo.Magnitude, 1)
	local dir = flatTo.Magnitude > 0.01 and flatTo.Unit or Vector3.new(0, 0, 1)

	local sp = Config.SHOOT_SPEED
	local hSpeed = (sp.min + (sp.max - sp.min) * power) * st.speed
	-- over-hitting (power above the sweet zone) makes the shot wild; a clean strike stays on target
	local wild = math.max(0, power - (Config.SETPIECE_SWEET_MAX or 0.9)) / (1 - (Config.SETPIECE_SWEET_MAX or 0.9))
	local weak = math.max(0, (Config.SETPIECE_SWEET_MIN or 0.55) - power) / (Config.SETPIECE_SWEET_MIN or 0.55)
	local spread = math.rad((Config.SETPIECE_BASE_SPREAD_DEG or 0.4) + wild * 5 + weak * 1.5) * st.spread
	dir = Util.rotateY(dir, (math.random() * 2 - 1) * spread)

	local g = Workspace.Gravity * Config.BALL_GRAVITY_SCALE
	local k = Config.BALL_AIR_DRAG or 0
	local t = dist / hSpeed
	if k > 1e-4 and k * dist / hSpeed < 0.9 then
		t = -math.log(1 - k * dist / hSpeed) / k -- flight time with air drag
	end
	local dy = target.Y - ballPos.Y
	local vSpeed = dy / t + 0.5 * g * t
	if k > 1e-4 then
		vSpeed = (dy + 0.5 * g * t * t) * k / (1 - math.exp(-k * t))
	end
	vSpeed = math.clamp(vSpeed + wild * 12 * (math.random() * 0.6 + 0.4), -6, 75)

	local curve
	if st.curve then
		local deg = st.curve.deg * (0.5 + 0.5 * power)
		curve = { side = side * st.curve.dir, deg = deg, rate = st.curve.rate, dur = st.curve.dur }
		-- the ball will bend on its way (BallService.applyCurve): pre-aim against the bend, found by simulating the flight,
		-- so a curled shot still finishes on the point the player aimed at
		local ux, uz = dir.X, dir.Z
		local function lateral(alpha)
			local hx, hz = rotXZ(ux, uz, alpha)
			local px, pz, sp, tt, dt = 0, 0, hSpeed, 0, 1 / 60
			local left, rate = math.rad(deg), math.rad(curve.rate)
			while tt < 6 do
				sp = sp * math.exp(-(Config.BALL_AIR_DRAG or 0) * dt)
				if left > 0 and tt < curve.dur and sp >= 22 then
					local da = math.min(rate * dt, left)
					left = left - da
					hx, hz = rotXZ(hx, hz, da * curve.side)
				end
				px, pz, tt = px + hx * sp * dt, pz + hz * sp * dt, tt + dt
				if px * ux + pz * uz >= dist then
					return -px * uz + pz * ux
				end
			end
			return 0
		end
		local alpha = 0
		for _ = 1, 8 do
			alpha = alpha - lateral(alpha) / dist
		end
		local nx, nz = rotXZ(dir.X, dir.Z, alpha)
		dir = Vector3.new(nx, 0, nz)
	end
	return dir, hSpeed, vSpeed, curve
end

local function onKick(player, ax, ay, power, style, side)
	local b = bucket[player]
	if not b or not b:take() then
		return
	end
	local a = active
	if not a or a.taker ~= player or os.clock() > a.untilT + 0.5 then
		return
	end
	ax = num(ax, -1.3, 1.3, 0)
	ay = num(ay, 0, 1.35, 0.4)
	power = num(power, 0.05, 1, 0.7)
	if type(style) ~= "string" or not STYLES[style] then
		style = "Normal"
	end
	side = (side == -1) and -1 or 1

	local ball = BallService.GetBall()
	if not ball then
		return
	end
	local dir, hSpeed, vSpeed, curve = SetPiece.Compute(a, ball.Position, ax, ay, power, style, side)

	unfreeze(player)
	BallService.Kick(player, dir, hSpeed, vSpeed, { kind = "SHOOT", shot = true, curve = curve })
	Remotes.get("KickPlayed"):FireAllClients(player.UserId, "SHOOT", power, style)
	SetPiece.End("kick")
end

function SetPiece.Init()
	stateFolder = ReplicatedStorage:FindFirstChild("SoccerState")
	if not stateFolder then
		stateFolder = Instance.new("Folder")
		stateFolder.Name = "SoccerState"
		stateFolder.Parent = ReplicatedStorage
	end
	local function add(p)
		bucket[p] = Util.newBucket(Config.RATE_ACTION.rate, Config.RATE_ACTION.burst)
	end
	for _, p in ipairs(Players:GetPlayers()) do
		add(p)
	end
	Players.PlayerAdded:Connect(add)
	Players.PlayerRemoving:Connect(function(p)
		bucket[p] = nil
		if active and active.taker == p then
			SetPiece.End("left")
		end
	end)
	Remotes.get("SetPieceKick").OnServerEvent:Connect(onKick)

	-- the taker kicked the ball in any other way (e.g. a normal pass button): the set piece is over
	local prev = BallService.OnKick
	BallService.OnKick = function(player, kind)
		if prev then
			prev(player, kind)
		end
		if active and active.taker == player then
			SetPiece.End("kick")
		end
	end
	clearAttrs()
end

return SetPiece
