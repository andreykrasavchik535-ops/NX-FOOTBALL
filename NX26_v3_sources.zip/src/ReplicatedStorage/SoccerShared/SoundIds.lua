local ReplicatedStorage = game:GetService("ReplicatedStorage")
local SoundIds = {}
SoundIds.Slots = { Whistle = "", Kick = "", Pass = "", Post = "", Goal = "", Save = "", Tackle = "", UIClick = "", UIHover = "", Crowd = "" }
SoundIds.Settings = { Whistle = { Volume = 0.7, Loop = false }, Kick = { Volume = 0.8, Loop = false }, Pass = { Volume = 0.6, Loop = false }, Post = { Volume = 0.9, Loop = false }, Goal = { Volume = 0.9, Loop = false }, Save = { Volume = 0.7, Loop = false }, Tackle = { Volume = 0.6, Loop = false }, UIClick = { Volume = 0.5, Loop = false }, UIHover = { Volume = 0.25, Loop = false }, Crowd = { Volume = 0.35, Loop = true } }
local ALIAS = { Pass = "Kick" }
function SoundIds.Normalize(id)
	if type(id) == "number" and id > 0 and id == math.floor(id) then return "rbxassetid://" .. string.format("%d", id) end
	if type(id) ~= "string" then return nil end
	local digits = string.match(id, "^%s*rbxassetid://(%d+)%s*$") or string.match(id, "^%s*(%d+)%s*$")
	if digits and tonumber(digits) and tonumber(digits) > 0 then return "rbxassetid://" .. digits end
	return nil
end
function SoundIds.Get(key) return SoundIds.Normalize(SoundIds.Slots[key]) end
function SoundIds.GetSettings(key) return SoundIds.Settings[key] or { Volume = 0.6, Loop = false } end
function SoundIds.Has(key) return SoundIds.Get(key) ~= nil end
function SoundIds.Resolve(name)
	local st = SoundIds.GetSettings(name)
	local folder = ReplicatedStorage:FindFirstChild("NXSounds")
	local template
	if folder then
		local obj = folder:FindFirstChild(name)
		if not (obj and obj:IsA("Sound")) and ALIAS[name] then obj = folder:FindFirstChild(ALIAS[name]) end
		if obj and obj:IsA("Sound") and obj.SoundId ~= "" then template = obj end
	end
	local s
	if template then s = template:Clone()
	else
		local id = SoundIds.Get(name)
		if not id and ALIAS[name] then id = SoundIds.Get(ALIAS[name]) end
		if not id then return nil end
		s = Instance.new("Sound"); s.SoundId = id
	end
	s.Name = "NX_" .. name; s.Volume = st.Volume; s.Looped = st.Loop
	return s
end
return SoundIds
